require("dotenv").config();
const express=require("express");
const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const app=express();
const PORT=process.env.PORT||3000;
const DB=path.join(__dirname,"orders.json");
app.use(express.json());
app.use(express.static(__dirname));
if(!fs.existsSync(DB)) fs.writeFileSync(DB,"[]","utf8");
const sessions=new Map();
function readOrders(){try{return JSON.parse(fs.readFileSync(DB,"utf8"))}catch{return[]}}
function writeOrders(o){fs.writeFileSync(DB,JSON.stringify(o,null,2),"utf8")}
function orderId(){return "FT-"+Date.now().toString().slice(-8)+"-"+crypto.randomBytes(2).toString("hex").toUpperCase()}
function token(req){const h=req.headers.authorization||"";return h.startsWith("Bearer ")?h.slice(7):null}
function auth(req,res,next){const t=token(req);if(!t||!sessions.has(t))return res.status(401).json({error:"Not authenticated"});req.admin=sessions.get(t);next()}
const users={nati:process.env.NATI_PASSWORD||"CHANGE_ME_NATI",dagim:process.env.DAGIM_PASSWORD||"CHANGE_ME_DAGIM"};
app.post("/api/login",(req,res)=>{const{username,password}=req.body||{};if(!username||!password||!Object.prototype.hasOwnProperty.call(users,username)||users[username]===`CHANGE_ME_${username.toUpperCase()}`||users[username]!==password)return res.status(401).json({error:"Invalid username or password"});const t=crypto.randomBytes(32).toString("hex");sessions.set(t,{username,createdAt:Date.now()});res.json({ok:true,token:t,username})});
app.post("/api/logout",auth,(req,res)=>{sessions.delete(token(req));res.json({ok:true})});
app.get("/api/orders",auth,(req,res)=>res.json(readOrders().sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt))));
app.post("/api/orders",(req,res)=>{const{playerId,playerName,phone,package:pkg,amount}=req.body||{};if(!playerId||!playerName||!phone||!pkg||!amount)return res.status(400).json({error:"Missing order information"});const o={orderId:orderId(),playerId:String(playerId).trim(),playerName:String(playerName).trim(),phone:String(phone).trim(),package:String(pkg),amount:Number(amount),paymentStatus:"Pending",orderStatus:"Pending Payment",message:"Waiting for payment verification.",createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};const all=readOrders();all.push(o);writeOrders(all);res.status(201).json(o)});
app.get("/api/order-status",(req,res)=>{const id=String(req.query.orderId||"").trim(),phone=String(req.query.phone||"").trim();const o=readOrders().find(x=>x.orderId===id&&x.phone===phone);if(!o)return res.status(404).json({error:"Order not found"});res.json({orderId:o.orderId,package:o.package,amount:o.amount,paymentStatus:o.paymentStatus,orderStatus:o.orderStatus,message:o.message,updatedAt:o.updatedAt})});
app.patch("/api/orders/:id/status",auth,(req,res)=>{const action=String(req.body?.action||"").toLowerCase();const all=readOrders();const i=all.findIndex(o=>o.orderId===req.params.id);if(i<0)return res.status(404).json({error:"Order not found"});const o=all[i];if(action==="verify"){o.paymentStatus="Verified";o.orderStatus="Processing";o.message="Your payment has been verified. Your top-up is being processed. We will be in touch shortly."}else if(action==="complete"){o.paymentStatus="Verified";o.orderStatus="Completed";o.message="Your top-up has been completed successfully. Thank you for using FireTop Ethiopia."}else if(action==="cancel"){o.paymentStatus="Not Verified";o.orderStatus="Cancelled";o.message="We could not confirm your payment, so this order has been cancelled. If you already paid, please contact us with your payment reference. We will be in touch shortly."}else return res.status(400).json({error:"Unknown action"});o.updatedAt=new Date().toISOString();o.updatedBy=req.admin.username;all[i]=o;writeOrders(all);res.json(o)});
app.get("/admin.html",(req,res)=>res.sendFile(path.join(__dirname,"admin.html")));
app.listen(PORT,()=>console.log(`FireTop server running on port ${PORT}`));
